This is a normal archive.
Contains documentation files.